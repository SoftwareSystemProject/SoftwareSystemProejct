package com.example.jpetstore.service;

import java.util.List;

import com.example.jpetstore.domain.Cart;

public interface CartService {

	Cart getCart();
}
