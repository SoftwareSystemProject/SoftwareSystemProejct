package com.example.jpetstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.jpetstore.domain.GroupItem;

@Service
public class GroupItemServiceImpl implements GroupItemService {

	@Override
	public List<GroupItem> findGroupItems() {
		// TODO Auto-generated method stub
		return null;
	}

}
