package com.example.jpetstore.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.jpetstore.domain.Cart;
import com.example.jpetstore.domain.GroupItem;

@Service
public class CartServiceImpl implements CartService {

	@Override
	public Cart getCart() {
		// TODO Auto-generated method stub
		return null;
	}

}
