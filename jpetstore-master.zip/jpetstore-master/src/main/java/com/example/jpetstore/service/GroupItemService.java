package com.example.jpetstore.service;

import java.util.List;

import com.example.jpetstore.domain.GroupItem;



public interface GroupItemService {

	List<GroupItem> findGroupItems();
}
